export const environment = {
  production: true,
  firebaseApiKey : 'AIzaSyCo6OMS7OcGN7msSG98Xlz2MmE96PhjArw'
};
