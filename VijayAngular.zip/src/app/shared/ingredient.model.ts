export class Ingredient
{
    // public name: string;
    // public amount : number;

    //We Can Directly Call It like Below

constructor(public name:string, public amount:number)
{
this.name=name;
this.amount=amount;
}

}